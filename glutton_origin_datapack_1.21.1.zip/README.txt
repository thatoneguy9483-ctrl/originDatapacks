ORIGINS: GLUTTON - eat past full
For Minecraft 1.21.1 + Fabric + Origins 1.13.x (pack_format 48). Pehkui is OPTIONAL.
Install: put the ZIP in <world>/datapacks/ (or Create World > Data Packs), make sure it is ENABLED, then /reload or restart.
Pick "Glutton" on the origin screen (or: /origin set @s origins:origin gluttony:glutton).
PRIMARY KEY (G) = Purge. SECONDARY KEY = Chomp (bind it in Controls).
If it does not show up, open logs/latest.log and search for "gluttony" - the exact failing file is named there.
